package actionhouse.app.enums;

public enum Menu {
    NONE,
    CUSTOMER,
    ARTICLE,
    BIDS,
    ANALYTICS,
    EXIT
}
