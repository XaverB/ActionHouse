package actionhouse.backend.bl;

public enum ArticleOrder {
    NAME,
    RESERVE_PRICE,
    HAMMER_PRICE,
    AUCTION_START_DATE
}
