package actionhouse.app.enums;

public enum ArticleMenu {
    NONE,
    CREATE,
    UPDATE,
    DELETE,
    SHOW,
    SHOW_ALL,
    EXIT
}
