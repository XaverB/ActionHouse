package actionhouse.backend.orm.domain;

public enum ArticleStatus {
    LISTED,
    AUCTION_RUNNING,
    SOLD,
    NOT_SOLD
}
