package actionhouse.app.enums;

public enum CustomerMenu {
    NONE,
    CREATE,
    UPDATE,
    DELETE,
    SHOW,
    SHOW_ALL,
    EXIT
}
