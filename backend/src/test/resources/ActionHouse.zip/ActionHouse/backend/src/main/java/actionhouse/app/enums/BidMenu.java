package actionhouse.app.enums;

public enum BidMenu {
    NONE,
    CREATE,
    DELETE,
    EXIT
}
