package actionhouse.app.enums;

public enum AnalyticsMenu {
    NONE,
    FIND_ARTICLE_BY_DESCRIPTION,
    GET_ARTICLE_PRICE,
    GET_TOP_SELLERS,
    GET_TOP_ARTICLES,
    EXIT
}
